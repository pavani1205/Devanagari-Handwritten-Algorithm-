from flask import *
from flask_sqlalchemy import *
import datetime
import sqlite3

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.secret_key = 'random string'
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = set(['jpeg', 'jpg', 'png', 'gif'])
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
db = SQLAlchemy(app)
mainarray = []

# ==========================================================================

class Register(db.Model):
	__tablename__='register'
	userId = db.Column(db.Integer,primary_key=True)
	password = db.Column(db.String(255))
	email = db.Column(db.String(255),unique=True)
	name = db.Column(db.String(255))
	address = db.Column(db.String(255))
	state = db.Column(db.String(255))
	phone = db.Column(db.String(255))

db.create_all()

#===============================================================================
class Content(db.Model):
	__tablename__='content'
	Id = db.Column(db.Integer,primary_key=True)
	Title = db.Column(db.String(255))
	description = db.Column(db.Text)
	Timestamp=db.Column(db.String(255), default=datetime.datetime.utcnow)
db.create_all()


#=============================================================================

def getLoginDetails():
	if 'email' not in session:
		loggedIn = False
		name = ''
		noOfItems = 0
	else:
		loggedIn = True
		stmt = "select userId,name from register where email='"+session['email']+"'"
		userId, name = db.engine.execute(stmt).fetchone()
	return (loggedIn,name)

#=================================================================================

@app.route("/register",methods = ['GET','POST'])
def register():
	if request.method =='POST':
		password = request.form['password']
		email = request.form['email']
		name = request.form['name']
		address = request.form['address']
		state = request.form['state']
		phone = request.form['phone']
		try:
			user = Register(password=password,email=email,name=name,address=address,state=state,phone=phone)
			db.session.add(user)
			db.session.commit()
			msg="registered successfully"
		except:
			db.session.rollback()
			msg="error ocuured"
	db.session.close()
	return render_template("login.html",error=msg)

#============================================================================================================
@app.route("/")
@app.route("/loginForm")
def loginForm():
        return render_template('login.html', error='')

# =================================================================================	

@app.route("/registerationForm")
def registrationForm():
    return render_template("register.html")

# =================================================================================	


@app.route("/login", methods = ['POST', 'GET'])
def login():
	mainarray = []
	loggedIn, name = getLoginDetails()
	if request.method == 'POST':
		email = request.form['email']
		password = request.form['password']
		if is_valid(email, password):
			session['email'] = email
			return redirect(url_for('blogentries'))
			
		else:
			error = 'Invalid UserId / Password'
			return render_template('login.html', error=error)

# =================================================================================
def is_valid(email,password):
	stmt = "SELECT email, password FROM register"
	data = db.engine.execute(stmt).fetchall()
	for row in data:
		if row[0] == email and row[1] == password:
			return True
	return False
#====================================================================================
@app.route("/new-entry")
def new_entry():
	loggedIn, name = getLoginDetails()
	if loggedIn:
		return render_template("new-entry.html")

@app.route("/entry",methods = ['POST', 'GET'])
def entry():
	loggedIn, name = getLoginDetails()
	if loggedIn:
		if request.method=='POST':
			Title=request.form['email']
			description=request.form['comment']
			try:
				content = Content(Title=Title,description=description)
				db.session.add(content)
				db.session.commit()
				msg="Posted successfully"
			except:
				db.session.rollback()
				msg="error ocuured"
				return render_template(new-entry.html,error=msg)
		db.session.close()
		return render_template("blogentry.html")


@app.route("/blogentries", methods = ['POST', 'GET'])
def blogentries():
	loggedIn, name = getLoginDetails()
	if loggedIn:
		stmt = "select Id,Title,Timestamp,description from content order by Id DESC"
		data=db.engine.execute(stmt).fetchall()
		for i in data:
			tuplearray=[]
			for j in i:
				tuplearray.append(j)
			
			mainarray.append(tuplearray)
		
		return render_template("blogentry.html",data=data,loggedIn=loggedIn,name=name,mainarray=mainarray)

@app.route("/desc/<pID>")
def desc(pID):
	for i in mainarray:
		if i[0]==int(pID):
			return render_template("desc.html",Title=i[1],description=i[3])

@app.route("/logout")
def logout():
	global mainarray
	mainarray=[]
	session.pop('email',None)
	return redirect(url_for('loginForm'))

if (__name__ == "__main__"):
	app.run(port=3001)
